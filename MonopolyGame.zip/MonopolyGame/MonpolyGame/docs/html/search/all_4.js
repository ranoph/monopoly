var searchData=
[
  ['execute_0',['execute',['../class_card.html#a9014c7a22a29ee4ad2b1a6b34edb580b',1,'Card']]]
];
