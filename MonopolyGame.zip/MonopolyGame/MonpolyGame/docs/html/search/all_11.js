var searchData=
[
  ['taxspace_0',['TaxSpace',['../class_tax_space.html',1,'']]],
  ['transfer_1',['transfer',['../class_resource_manager.html#a2aeeda22d79b4d3dce084c32e4f1b7af',1,'ResourceManager']]],
  ['transfermoneyto_2',['transferMoneyTo',['../class_player.html#aac5144d8d1b092d034747c22a382ac3f',1,'Player']]],
  ['transferpropertyto_3',['transferPropertyTo',['../class_player.html#a0764c47c052226a55d5dd3edd3585043',1,'Player']]],
  ['trytoleavejail_4',['tryToLeaveJail',['../class_player.html#a860e9fd0e220441cde502d31b94ee01f',1,'Player']]],
  ['type_5',['type',['../class_space.html#a671c5f6b77a5a290c22917ac63c6bbee',1,'Space']]]
];
