var searchData=
[
  ['name_0',['name',['../class_space.html#aa68f029d1db308b81d4e218aa701cf2d',1,'Space::name'],['../class_property.html#ac8136e02edb3fa088b620392c66b8dde',1,'Property::name']]]
];
