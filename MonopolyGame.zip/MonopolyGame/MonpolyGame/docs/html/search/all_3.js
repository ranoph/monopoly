var searchData=
[
  ['dice_0',['Dice',['../class_dice.html',1,'Dice'],['../class_dice.html#a6b9eadd945ad8fd3840379c8824e5d48',1,'Dice::Dice()']]]
];
