var searchData=
[
  ['position_0',['position',['../class_space.html#ae75d9ca2365fc008f7db821ea9a1cb96',1,'Space::position'],['../class_property.html#ad1b0bb9a42b951419d5934abefcc25e8',1,'Property::position']]],
  ['price_1',['price',['../class_property.html#a0228e27a029bcd8625e69cee6947feca',1,'Property']]]
];
