var searchData=
[
  ['type_0',['type',['../class_space.html#a671c5f6b77a5a290c22917ac63c6bbee',1,'Space']]]
];
